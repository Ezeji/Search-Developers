package com.example.franklinezeji.intermediatequalificationapp;

import static android.R.attr.description;

/**
 * Created by user on 8/3/2017.
 */

public class ListItem {

    private String user_name;
    private String imageUrl;

    public ListItem(String user_name, String imageUrl) {
        this.user_name = user_name;
        this.imageUrl = imageUrl;
    }

    public String getUser_name() {
        return user_name;
    }


    public String getImageUrl() {
        return imageUrl;
    }
}
